import turtle
from tkinter import *
import subprocess
import os 
import random

BASE = os.path.dirname(os.path.abspath(__file__))

PRISMLAUNCHER_PATH = r"C:\Users\YOUSS\AppData\Local\Programs\PrismLauncher\PrismLauncher.exe"
DEFAULT_INSTANCE = "1.21.5"

def open_mc():
    command = r'Start-Process "shell:AppsFolder\Microsoft.MinecraftUWP_8wekyb3d8bbwe!App"'
    subprocess.run(["powershell", "-Command", command], shell=True)

def open_fort():
    subprocess.run(["powershell","-Command",'Start-Process "com.epicgames.launcher://apps/Fortnite?action=launch&silent=true"'])

def open_ha():
    file_path = os.path.join(BASE, "HorionInjector.exe")
    os.startfile(file_path)

def open_J_MC():
    if not os.path.exists(PRISMLAUNCHER_PATH):
        print(f"ERROR: PrismLauncher not found at {PRISMLAUNCHER_PATH}")
        return
    try:
        cmd = [PRISMLAUNCHER_PATH, "--launch", DEFAULT_INSTANCE]
        subprocess.Popen(cmd)
        print("PrismLauncher launched successfully!")
    except Exception as e:
        print(f"Failed to launch PrismLauncher: {e}")

opens = [open_fort, open_J_MC, open_mc]
random_open = random.choice(opens)

t = turtle.Turtle()
window = turtle.getcanvas().winfo_toplevel()
window.resizable(False, False)
screen = turtle.Screen()
canvas = screen.getcanvas()
screen.title("epimc")

bg = os.path.join(BASE, "back.gif")
if os.path.exists(bg):
    screen.bgpic(bg)

screen.setup(width=900, height=760)
screen.tracer(0)

def style_button(btn, bg, fg):
    btn.config(font=("Comic Sans MS", 10, "bold"), bg=bg, fg=fg, activebackground="#444", relief=RAISED, bd=3)

def add_hover_effect(btn, bg_hover, bg_default):
    def on_enter(e):
        btn.config(bg=bg_hover)
    def on_leave(e):
        btn.config(bg=bg_default)
    btn.bind("<Enter>", on_enter)
    btn.bind("<Leave>", on_leave)

buttons = [
    ("open mc 🚀", open_mc, 0, 90, "#4CAF50"),
    ("open fort 🎯", open_fort, 800, 100, "#2196F3"),
    ("open hacker mc 💻", open_ha, 0, 50, "#FF5722"),
    ("open java mc 🧨", open_J_MC, 0, 1, "#9C27B0"),
    ("open random 🎲", random_open, 0, 130, "#607D8B"),
]

for text, cmd, x, y, color in buttons:
    btn = Button(canvas.master, text=text, command=cmd)
    style_button(btn, color, "white")
    add_hover_effect(btn, "#777", color)
    btn.place(x=x, y=y)

turtle.done()
